function Evento(tipo, objeto, data) {
	this.tipo = tipo;
	this.objeto = objeto;
	this.data = data;
}