
var stats = {};

stats.reset = function () {
	stats.eStatsList = [];
	stats.sStatsList = [];
	stats.fStatsList = [];

	stats._tTotalEntidadesSistema = 0;
	stats._tTotalEntidadesFila = 0;

	stats.nMedioEntidadesFila = 0;
	stats.tMedioEntidadesFila = 0;
	stats.tMedioEntidadesSistema = 0;
	stats.contaEntidades = 0;

	stats.taxaMediaUsoS1 = 0;
	stats.taxaMediaUsoS2 = 0;
	stats.contaTrocas = 0;

	stats.tFalhaS1 = 0;
	stats.tFalhaS2 = 0;
	stats.tMedioFalhaS1 = 0;
	stats.tMedioFalhaS2 = 0;
	stats.contaFalhaS1 = 0;
	stats.contaFalhaS2 = 0;
};

stats.initLists = function () {
	stats.eStatsList.push({ tipo: "Nº de Pessoas Atendida", valor: stats.nMedioEntidadesFila });
	stats.eStatsList.push({ tipo: "Nº de Pessoa(s) na  Fila", valor: stats.tMedioEntidadesFila });
	stats.eStatsList.push({ tipo: "Nº de Pessoas / Sistema", valor: stats.tMedioEntidadesSistema });
	stats.eStatsList.push({ tipo: "Nº de Registro / Pessoa", valor: stats.contaEntidades });

	stats.sStatsList.push({ tipo: "1º Servidor (uso/médio)", valor: stats.taxaMediaUsoS1 })
	stats.sStatsList.push({ tipo: "2º Servidor (uso/médio)", valor: stats.taxaMediaUsoS2 });
	stats.sStatsList.push({ tipo: "Contagem de trocas", valor: stats.contaTrocas });

	stats.fStatsList.push({ tipo: "1º Servidor ñ respondeu", valor: stats.tFalhaS1 });
	stats.fStatsList.push({ tipo: "2º Servidor ñ respondeu", valor: stats.tFalhaS2 });
	stats.fStatsList.push({ tipo: "Tempo médio falha S1", valor: stats.tMedioFalhaS1 + "%" });
	stats.fStatsList.push({ tipo: "Tempo médio falha S2", valor: stats.tMedioFalhaS2 + "%" });
	stats.fStatsList.push({ tipo: "Contagem falha S1", valor: stats.contaFalhaS1 });
	stats.fStatsList.push({ tipo: "Contagem falha S2", valor: stats.contaFalhaS2 });
}

stats.updateLists = function () {
	stats.eStatsList[0].valor = stats.nMedioEntidadesFila.toFixed(2);
	stats.eStatsList[1].valor = stats.tMedioEntidadesFila;
	stats.eStatsList[2].valor = stats.tMedioEntidadesSistema;
	stats.eStatsList[3].valor = stats.contaEntidades;

	stats.sStatsList[0].valor = stats.taxaMediaUsoS1 + "%";
	stats.sStatsList[1].valor = stats.taxaMediaUsoS2 + "%";
	stats.sStatsList[2].valor = stats.contaTrocas;

	stats.fStatsList[0].valor = stats.tFalhaS1;
	stats.fStatsList[1].valor = stats.tFalhaS2;
	stats.fStatsList[2].valor = stats.tMedioFalhaS1 + "%";
	stats.fStatsList[3].valor = stats.tMedioFalhaS2 + "%";
	stats.fStatsList[4].valor = stats.contaFalhaS1;
	stats.fStatsList[5].valor = stats.contaFalhaS2;
};