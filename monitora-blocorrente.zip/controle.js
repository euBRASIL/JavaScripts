var listProbabilidades = [];
listProbabilidades.push({ vars: varsEnum.TEC1, prob: probEnum.CONSTANTE, params: 10 });
listProbabilidades.push({ vars: varsEnum.TEC2, prob: probEnum.CONSTANTE, params: 20 });
listProbabilidades.push({ vars: varsEnum.TS1, prob: probEnum.CONSTANTE, params: 15 });
listProbabilidades.push({ vars: varsEnum.TS2, prob: probEnum.CONSTANTE, params: 15 });
listProbabilidades.push({ vars: varsEnum.TEF1, prob: probEnum.CONSTANTE, params: 100 });
listProbabilidades.push({ vars: varsEnum.TEF2, prob: probEnum.CONSTANTE, params: 200 });
listProbabilidades.push({ vars: varsEnum.TF1, prob: probEnum.CONSTANTE, params: 10 });
listProbabilidades.push({ vars: varsEnum.TF2, prob: probEnum.CONSTANTE, params: 20 });

function toHHMM(minutes) {
	var hours = Math.floor(minutes / 60);
	minutes = minutes % 60;
	if (hours < 10) { hours = "0" + hours; }
	if (minutes < 10) { minutes = "0" + minutes; }
	return hours + ':' + minutes;
}

function createRowTable(objects) {
	var row, cell;
	row = document.createElement("tr");
	objects.forEach(function (object) {
		cell = document.createElement("td");
		cell.appendChild(document.createTextNode(object));
		row.appendChild(cell);
	});
	return row;
}

function init() {
	var velSlider = document.getElementById("velSim");
	getVelocidadeSim = function () { return velSlider.value / 100; };
	velSlider.addEventListener('input', function (evt) {
		getVelocidadeSim = function () { return velSlider.value / 100; };
	}, false);

	updateTableProb();
	updateTableStats();
}

function updateTableEvents(evento, eventoFuturo) {

	var table = document.getElementById("tabelaEvento");
	var tbody = table.getElementsByTagName("tbody")[0];
	while (tbody.firstChild)
		tbody.removeChild(tbody.firstChild);
	listaEventos.forEach(function (evento) {
		var row = createRowTable([Object.keys(evEnum)[evento.tipo], evento.objeto.nome, toHHMM(evento.data)]);
		tbody.appendChild(row);
	});

	table = document.getElementById("eventoAtual");
	tbody = table.getElementsByTagName("tbody")[0];
	if (evento) {
		var row = createRowTable([Object.keys(evEnum)[evento.tipo], evento.objeto.nome, toHHMM(evento.data)]);
		if (tbody.firstChild)
			tbody.replaceChild(row, tbody.firstChild);
		else
			tbody.appendChild(row);
	}

	table = document.getElementById("eventoFuturo");
	tbody = table.getElementsByTagName("tbody")[0];
	if (eventoFuturo) {
		row = createRowTable([Object.keys(evEnum)[eventoFuturo.tipo], eventoFuturo.objeto.nome, toHHMM(eventoFuturo.data)]);
		if (tbody.firstChild)
			tbody.replaceChild(row, tbody.firstChild);
		else
			tbody.appendChild(row);
	} else
		if (tbody.firstChild)
			tbody.removeChild(tbody.firstChild);

	table = document.getElementById("servers");
	tbody = table.getElementsByTagName("tbody")[0];
	while (tbody.firstChild)
		tbody.removeChild(tbody.firstChild);
	[server1, server2].forEach(function (server) {
		var estado = server.falha ? "Falha" : server.livre ? "Livre" : "Ocupado";
		var row = createRowTable([server.nome, estado, server.fila.length]);
		tbody.appendChild(row);
	});

	table = document.getElementById("entities");
	tbody = table.getElementsByTagName("tbody")[0];
	while (tbody.firstChild)
		tbody.removeChild(tbody.firstChild);
	[server1, server2].forEach(function (server) {
		if (server.atendendo) {
			var entidade = server.atendendo;
			var row = createRowTable([entidade.id, entidade.tipo, server.nome, "Trabalhando"]);
			tbody.appendChild(row);
		}
	});
	[server1, server2].forEach(function (server) {
		server.fila.forEach(function (entidade) {
			var row = createRowTable([entidade.id, entidade.tipo, server.nome, "Fila"]);
			tbody.appendChild(row);
		});
	});

}

function updateTableProb() {
	var table = document.getElementById("varsProb");
	var tbody = table.getElementsByTagName("tbody")[0];
	while (tbody.firstChild)
		tbody.removeChild(tbody.firstChild);
	listProbabilidades.forEach(function (prob) {
		var row = createRowTable([Object.keys(varsEnum)[prob.vars], Object.keys(probEnum)[prob.prob], prob.params]);
		tbody.appendChild(row);
	});
}

function updateTableStats() {

	stats.updateLists();

	var table = document.getElementById("statsEntitiesTable");
	var tbody = table.getElementsByTagName("tbody")[0];
	while (tbody.firstChild)
		tbody.removeChild(tbody.firstChild);
	stats.eStatsList.forEach(function (stat) {
		var row = createRowTable([stat.tipo, stat.valor]);
		tbody.appendChild(row);
	});

	table = document.getElementById("statsServersTable");
	tbody = table.getElementsByTagName("tbody")[0];
	while (tbody.firstChild)
		tbody.removeChild(tbody.firstChild);
	stats.sStatsList.forEach(function (stat) {
		var row = createRowTable([stat.tipo, stat.valor]);
		tbody.appendChild(row);
	});

	table = document.getElementById("statsFaultTable");
	tbody = table.getElementsByTagName("tbody")[0];
	while (tbody.firstChild)
		tbody.removeChild(tbody.firstChild);
	stats.fStatsList.forEach(function (stat) {
		var row = createRowTable([stat.tipo, stat.valor]);
		tbody.appendChild(row);
	});
}