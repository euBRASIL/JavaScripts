function Entidade(tipo, entrada, id) {
	this.id = id;
	this.tipo = tipo;
	this.entrada = entrada;
	this.nome = "Grupo " + id;
}