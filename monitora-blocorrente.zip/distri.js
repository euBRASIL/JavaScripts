dist = {

	constante: function (val) {
		return function () {
			return val;
		};
	},

	exponencial: function (lambda) {
		return function () {
			return ~~(-Math.log(Math.random()) * lambda);
		};
	},

	//math.js (http://mathjs.org/)
	normal: function (mean, sd) {
		return function () {
			var u1 = Math.random();
			var u2 = Math.random();
			return ~~(sd * Math.pow(-2 * Math.log(u1), 0.5) * Math.cos(2 * Math.PI * u2) + mean);
		};
	},

	triangular: function (min, mode, max) {
		return function () {
			var r = Math.random();
			if (r <= ((mode - min) / (mode - max)))
				return ~~(min + Math.sqrt(r * (mode - min)(max - min)));
			return ~~(max - Math.sqrt((1 - r) * (max - mode) * (max - min)));
		};
	},
	
	uniforme: function (min, max) {
		return function () {
			return ~~(Math.random() * (max - min) + min);
		};
	}
};