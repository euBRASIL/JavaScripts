function Servidor(id, getTS) {
	this.getTS = getTS;
	this.id = id;
	this.livre = true;
	this.falha = false;
	this.fila = new Array();
	this.atendendo;
	this.nome = "Servidor " + id;

	this.stats = {};
	this.stats.tempoOcupado = 0;
	this.stats.contaFalhas = 0;
	this.stats.tempoFalhaAtual = 0;
	this.stats.tempoFalhaTotal = 0;
}

Servidor.prototype.recebeEntidade = function (entidade) {
	if (this.falha)
		return 'falha';
	if (this.livre) {
		entidade.servidor = this;
		entidade.inicioAtendimento = entidade.entrada;
		this.atendendo = entidade;
		this.livre = false;
		return new Evento(evEnum.Debito, entidade, entidade.entrada + this.getTS());
	} else
		this.enfileiraEntidade(entidade);
	return 'ocupado';
};

Servidor.prototype.atendeProxima = function (relogio) {
	if (this.falha) {
		this.livre = true;
		return 'falha';
	}
	if (!this.livre) {
		this.stats.tempoOcupado += relogio - this.atendendo.inicioAtendimento;
		if (this.fila.length > 0) {
			var entidade = this.fila.shift();
			entidade.inicioAtendimento = relogio;
			this.atendendo = entidade;
			return new Evento(evEnum.Debito, entidade, relogio + this.getTS());
		}
	}
	this.livre = true;
	this.atendendo = null;
	return 'livre';
};

Servidor.prototype.enfileiraEntidade = function (entidade) {
	entidade.servidor = this;
	this.fila.push(entidade);
};

Servidor.prototype.falhar = function (relogio) {
	this.falha = true;
	this.stats.contaFalhas++;
	this.stats.tempoFalhaAtual = relogio;
};

Servidor.prototype.recFalha = function (relogio) {
	this.falha = false;
	this.stats.tempoFalhaTotal += relogio - this.stats.tempoFalhaAtual;
	this.stats.tempoFalhaAtual = 0;
	if (this.livre)
		return this.atendeProxima(relogio);
	return 'ocupado';
};

Servidor.prototype.getTS;