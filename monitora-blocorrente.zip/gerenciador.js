function eventsOrderer(evt1, evt2) {
	return evt1.data - evt2.data;
};

var getVelocidadeSim;
var getTec1 = dist.constante(10);
var getTec2 = dist.constante(20);
var getTS1 = dist.constante(15);
var getTS2 = dist.constante(15);
var getTef1 = dist.constante(100);
var getTef2 = dist.constante(200);
var getTf1 = dist.constante(10);
var getTf2 = dist.constante(20);
var server1 = new Servidor(1, getTS1);
var server2 = new Servidor(2, getTS2);
stats.reset();
stats.initLists();
var listaEventos = [];
var pausa = false;
var simulando = false;
var relogio = 0.0;

function updateProb() {
	var variavel = +document.getElementById("selVar").value;
	var distProb = +document.getElementById("selDist").value;
	var value1 = +document.getElementById("input1").value;
	var value2 = +document.getElementById("input2").value;
	var value3 = +document.getElementById("input3").value;

	var varDist = listProbabilidades[variavel];
	varDist.prob = distProb;

	var funcProb;
	switch (distProb) {
		case probEnum.CONSTANTE:
			funcProb = dist.constante(value1);
			varDist.params = value1;
			break;
		case probEnum.EXPONENCIAL:
			funcProb = dist.exponencial(value1);
			varDist.params = value1;
			break;
		case probEnum.NORMAL:
			funcProb = dist.normal(value1, value2);
			varDist.params = [value1, value2];
			break;
		case probEnum.TRIANGULAR:
			funcProb = dist.triangular(value1, value2, value3);
			varDist.params = [value1, value2, value3];
			break;
		case probEnum.UNIFORME:
			funcProb = dist.uniforme(value1, value2);
			varDist.params = [value1, value2];
			break;
		default:
			break;
	}

	switch (variavel) {
		case varsEnum.TEC1:
			getTec1 = funcProb;
			break;
		case varsEnum.TEC2:
			getTec2 = funcProb;
			break;
		case varsEnum.TS1:
			getTS = funcProb;
			break;
		case varsEnum.TS2:
			getTS = funcProb;
			break;
		case varsEnum.TEF1:
			getTef1 = funcProb;
			break;
		case varsEnum.TEF2:
			getTef2 = funcProb;
			break;
		case varsEnum.TF1:
			getTf1 = funcProb;
			break;
		case varsEnum.TF2:
			getTf2 = funcProb;
			break;
		default:
			break;
	}

	updateTableProb();
}

function gerenciaChegada(serverPrincipal, serverReserva, entidade) {
	var resposta = serverPrincipal.recebeEntidade(entidade);
	if (resposta == 'falha') {
		resposta = serverReserva.recebeEntidade(entidade);
		if (resposta == 'falha')
			serverPrincipal.enfileiraEntidade(entidade);
		else {
			stats.contaTrocas++;
			if (resposta != 'ocupado') {
				listaEventos.push(resposta);
				return resposta;
			}
		}
	} else if (resposta != 'ocupado') {
		listaEventos.push(resposta);
		return resposta;
	}
}

function proximoEvento() {
	var eventoFuturo;
	var evento = listaEventos.shift();
	var relogioOld = relogio;
	relogio = evento.data;
	var periodo = relogio - relogioOld;
	switch (evento.tipo) {
		case evEnum.Credito:
			switch (evento.objeto.tipo) {
				case 1:
					eventoFuturo = gerenciaChegada(server1, server2, evento.objeto);
					break;
				case 2:
					eventoFuturo = gerenciaChegada(server2, server1, evento.objeto);
					break;
				default:
					break;
			}
			break;
		case evEnum.Debito:
			var resposta = evento.objeto.servidor.atendeProxima(relogio);
			if (resposta != 'livre' && resposta != 'falha') {
				listaEventos.push(resposta);
				eventoFuturo = resposta;
			}
			stats.contaEntidades++;
			stats._tTotalEntidadesSistema += relogio - evento.objeto.entrada;
			stats._tTotalEntidadesFila += evento.objeto.inicioAtendimento - evento.objeto.entrada;
			stats.tMedioEntidadesSistema = ~~(stats._tTotalEntidadesSistema / stats.contaEntidades);
			stats.tMedioEntidadesFila = ~~(stats._tTotalEntidadesFila / stats.contaEntidades);
			break;
		case evEnum.FALHA:
			evento.objeto.falhar(evento.data);
			stats.contaFalhaS1 = server1.stats.contaFalhas;
			stats.contaFalhaS2 = server2.stats.contaFalhas;
			break;
		case evEnum.RECFALHA:
			resposta = evento.objeto.recFalha(relogio);
			if (resposta != 'livre' && resposta != 'ocupado') {
				listaEventos.push(resposta);
				eventoFuturo = resposta;
			}
			stats.tFalhaS1 = server1.stats.tempoFalhaTotal;
			stats.tFalhaS2 = server2.stats.tempoFalhaTotal;
			break;
		default:
			break;
	}
	stats.nMedioEntidadesFila = (stats.nMedioEntidadesFila * (relogioOld / relogio)) + ((server1.fila.length + server2.fila.length) * (periodo / relogio));

	stats.taxaMediaUsoS1 = ~~(server1.stats.tempoOcupado / relogio * 100);
	stats.taxaMediaUsoS2 = ~~(server2.stats.tempoOcupado / relogio * 100);

	stats.tMedioFalhaS1 = ~~(stats.tFalhaS1 / relogio * 100);
	stats.tMedioFalhaS2 = ~~(stats.tFalhaS2 / relogio * 100);

	listaEventos.sort(eventsOrderer);
	updateTableEvents(evento, eventoFuturo);
	updateTableStats();

	if (!pausa && listaEventos.length > 0)
		setTimeout(proximoEvento, periodo * 6000 * getVelocidadeSim());
	if (listaEventos.length == 0) {
		document.getElementById("nextE").disabled = true;
	}
}

function controlSimulation() {
	if (!simulando) {
		simulando = true;
		document.getElementById("startB").disabled = true;
		if (pausa)
			document.getElementById("nextE").disabled = false;
		var changeProb = document.getElementById("changeProb");
		for (var child in changeProb.children) {
			child = document.getElementById(child);
			if (child)
				child.disabled = true;
		}
		document.getElementById("inputTS").disabled = true;
		startSimulation();
		return;
	}
}

function pauseSimulation() {
	if (!pausa) {
		pausa = true;
		document.getElementById("pauseB").textContent = "Continuar";
		if (simulando)
			document.getElementById("nextE").disabled = false;
		return;
	}
	pausa = false;
	document.getElementById("pauseB").textContent = "Pausar";
	document.getElementById("nextE").disabled = true;
	if (simulando)
		proximoEvento();

}

function startSimulation() {
	var tempoDeSimulacao = document.getElementById("inputTS").value;

	var id = 1;
	for (var relogio = getTec1(); relogio < tempoDeSimulacao; relogio += getTec1(), id++)
		listaEventos.push(new Evento(evEnum.Credito, new Entidade(1, relogio, id), relogio));

	for (relogio = getTec2(); relogio < tempoDeSimulacao; relogio += getTec2(), id++)
		listaEventos.push(new Evento(evEnum.Credito, new Entidade(2, relogio, id), relogio));

	for (relogio = getTef1(); relogio < tempoDeSimulacao; relogio += getTef1()) {
		listaEventos.push(new Evento(evEnum.FALHA, server1, relogio));
		relogio += getTf1();
		listaEventos.push(new Evento(evEnum.RECFALHA, server1, relogio));
	}

	for (relogio = getTef2(); relogio < tempoDeSimulacao; relogio += getTef2()) {
		listaEventos.push(new Evento(evEnum.FALHA, server2, relogio));
		relogio += getTf2();
		listaEventos.push(new Evento(evEnum.RECFALHA, server2, relogio));
	}

	listaEventos.sort(eventsOrderer);

	updateTableEvents();

	if (!pausa)
		proximoEvento();
}