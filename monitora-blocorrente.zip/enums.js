
var evEnum = {
	Credito: 0,
	Debito: 1,
	FALHA: 2,
	RECFALHA: 3
};


var probEnum = {
	CONSTANTE: 0,
	EXPONENCIAL: 1,
	NORMAL: 2,
	TRIANGULAR: 3,
	UNIFORME: 4
};


var varsEnum = {
	TEC1: 0,
	TEC2: 1,
	TS1: 2,
	TS2: 3,
	TEF1: 4,
	TEF2: 5,
	TF1: 6,
	TF2: 7
};