! function(e) {
    "use strict";
    e.fn.tree_structure = function(t) {
        var i = {
            add_option: !1,
            edit_option: !1,
            delete_option: !1,
            confirm_before_delete: !1,
            fullwidth_option: !1,
            align_option: "center",
            draggable_option: !1
        };
        return this.each(function() {
            t && e.extend(i, t), e.fn.tree_structure.destroy = function() {
                e(document).off("click", "." + v + "[rel = " + g + "] span.add_action"), e(document).off("click", "." + v + "[rel = " + g + "] span.edit_action"), e(document).off("click", "." + v + "[rel = " + g + "] span.delete_action"), e(document).off("click", "." + v + "[rel = " + g + "] b.thide"), e(document).off("mouseenter mouseleave", "." + v + "[rel = " + g + "] li > div"), e(document).off("click", "." + v + "[rel = " + g + "] span.highlight"), e(document).off("click", ".tree_view_popup .close"), e(document).off("click", "input.submit"), e(document).off("click", "img.close"), e(document).off("click", "input.edit")
            };
            var l = i.add_option,
                s = i.edit_option,
                a = i.delete_option,
                n = i.confirm_before_delete,
                d = i.fullwidth_option,
                o = i.align_option,
                c = i.draggable_option,
                r = '<span class="vertical"></span>',
                h = '<span class="horizontal"></span>',
                p = 1 == l ? '<span class="add_action" title="Add"></span>' : "",
                f = 1 == s ? '<span class="edit_action" title="Update"></span>' : "",
                u = 1 == a ? '<span class="delete_action" title="Delete"></span>' : "",
                m = '<span class="highlight" title="Highlight"></span>',
                v = e(this).attr("class"),
                g = e(this).attr("rel"),
                _ = "pageload";
            if ("center" != o && e("." + v + "[rel = " + g + "] li").css({
                    "text-align": o
                }), d) {
                var b, x, k = 0;
                if (e("." + v + "[rel = " + g + "] li li").length > 0) {
                    e("." + v + "[rel = " + g + "] li li").each(function() {
                        var t = e(this).width();
                        (0 == k || t > b) && (b = e(this).width(), x = e(this)), k++
                    });
                    for (var C = x.closest("ul").children("li").eq(0).nextAll().length, w = parseInt(0), y = 0; y <= C; y++) w += parseInt(x.closest("ul").children("li").eq(y).outerWidth(), 10);
                    e("." + v + "[rel = " + g + "]").closest("div").width(w + 750)
                }
            }

            function j() {
                e("." + v + "[rel = " + g + "] li").each(function() {
                    var t;
                    "pageload" == _ && ((t = e(this)).prepend(r + h).children("div").prepend(p + u + f), 0 != t.children("ul").length && (t.hasClass("thide") ? t.children("div").prepend('<b class="thide tshow"></b>') : t.children("div").prepend('<b class="thide"></b>')), t.children("div").prepend(m)),
                        function(t) {
                            var i = e("." + v + "[rel = " + g + "]").offset().left;
                            i = parseInt(i, 10);
                            var l = t.children("div").outerWidth(!0) / 2,
                                s = t.children("div").offset().left;
                            if (null != t.parents("li").offset()) var a = t.parents("li").offset().top;
                            var n = t.offset().top - a - t.parents("li").children("div").outerHeight(!0) / 2;
                            if (t.children("span.vertical").css({
                                    height: n,
                                    "margin-top": -n,
                                    "margin-left": l,
                                    left: s - i
                                }), null == t.parents("li").offset()) var d = 0;
                            else d = t.parents("li").children("div").offset().left + t.parents("li").children("div").width() / 2 - (s + t.children("div").width() / 2);
                            var o = d < 0 ? -Math.abs(d) + l : l;
                            t.children("span.horizontal").css({
                                width: Math.abs(d),
                                "margin-top": -n,
                                "margin-left": o,
                                left: s - i
                            })
                        }(e(this))
                })
            }

            function z() {
                D(), e("." + v + "[rel = " + g + "] li > div").draggable({
                    cursor: "move",
                    distance: 40,
                    zIndex: 5,
                    revert: !0,
                    revertDuration: 100,
                    snap: ".tree li div",
                    snapMode: "inner",
                    start: function(t, i) {
                        e("li.li_children").removeClass("li_children"), e(this).closest("li").addClass("li_children")
                    },
                    stop: function(e, t) {
                        D()
                    }
                })
            }

            function D() {
                e("." + v + "[rel = " + g + "] li > div").droppable({
                    accept: ".tree li div",
                    drop: function(t, i) {
                        e("div.check_div").removeClass("check_div"), e(".li_children div").addClass("check_div");
                        var l = e(this);
                        if (l.hasClass("check_div")) alert("Cant Move on Child Element.");
                        else {
                            var s = {
                                action: "drag",
                                id: e(i.draggable[0]).attr("id"),
                                parent_id: l.attr("id"),
                                tree_id: g
                            };
                            e.ajax({
                                type: "POST",
                                url: "admin-ajax.php",
                                data: s,
                                success: function(e) {}
                            }), 0 == l.next("ul").length ? l.after("<ul><li>" + e(i.draggable[0]).attr({
                                style: ""
                            }).closest("li").html() + "</li></ul>") : e(this).next("ul").append("<li>" + e(i.draggable[0]).attr({
                                style: ""
                            }).closest("li").html() + "</li>"), 1 == e(i.draggable[0]).closest("ul").children("li").length ? e(i.draggable[0]).closest("ul").remove() : e(i.draggable[0]).closest("li").remove(), j(), z()
                        }
                    }
                })
            }
            e("." + v + "[rel = " + g + "] li.thide").each(function() {
                e(this).children("ul").hide()
            }), j(), _ = "others", e(window).resize(function() {
                j()
            }), e(document).on("click", "." + v + "[rel = " + g + "] b.thide", function() {
                e(this).toggleClass("tshow"), e(this).closest("li").toggleClass("thide").children("ul").toggle(), j()
            }), e(document).on("mouseenter mouseleave", "." + v + "[rel = " + g + "] li > div", function(t) {
                "mouseenter" == t.type || "mouseover" == t.type ? (e("." + v + "[rel = " + g + "] li > div.current").removeClass("current"), e("." + v + "[rel = " + g + "] li > div.children").removeClass("children"), e("." + v + "[rel = " + g + "] li > div.parent").removeClass("parent"), e(this).addClass("current"), e(this).closest("li").children("ul").children("li").children("div").addClass("children"), e(this).closest("li").closest("ul").closest("li").children("div").addClass("parent"), e(this).children("span.highlight, span.add_action, span.delete_action, span.edit_action").show()) : e(this).children("span.highlight, span.add_action, span.delete_action, span.edit_action").hide()
            }), e(document).on("click", "." + v + "[rel = " + g + "] span.highlight", function() {
                "tree" != e(this).closest("ul").attr("class") && (e("." + v + "[rel = " + g + "] li.highlight").removeClass("highlight"), e("." + v + "[rel = " + g + "] li > div.parent").removeClass("parent"), e("." + v + "[rel = " + g + "] li > div.children").removeClass("children"), e(this).closest("li").addClass("highlight"), e(".highlight li > div").addClass("children"), function e(t) {
                    if (t.length > 0) return t.children("div").addClass("parent"), t = t.closest("li").closest("ul").closest("li"), e(t)
                }(e(this).closest("li").closest("ul").closest("li")), d && e("." + v + "[rel = " + g + "]").parent("div").parent("div").scrollLeft(0), e("." + v + "[rel = " + g + "] li > div").not(".parent, .current, .children").closest("li").addClass("tnone"), e("." + v + "[rel = " + g + "] li div b.thide.tshow").closest("div").closest("li").children("ul").addClass("tshow"), e("." + v + "[rel = " + g + "] li div b.thide").addClass("tnone"), 0 == e(".back_btn").length && e("." + v + "[rel = " + g + "]").prepend('<img src="images/back.png" class="back_btn" />'), j(), e(".back_btn").click(function() {
                    e("." + v + "[rel = " + g + "] ul.tshow").removeClass("tshow"), e("." + v + "[rel = " + g + "] li.tnone").removeClass("tnone"), e("." + v + "[rel = " + g + "] li div b.thide").removeClass("tnone"), e(this).remove(), j()
                }))
            }), e("." + v + "[rel = " + g + "] .view_btn").length > 0 && (e(document).on("click", "." + v + "[rel = " + g + "] .view_btn", function() {
                var t = {
                    action: "viewdetail",
                    view_ele_id: e(this).closest("div").attr("id"),
                    tree_id: g
                };
                e.ajax({
                    type: "POST",
                    url: "admin-ajax.php",
                    data: t,
                    success: function(t) {
                        e("body").append(t)
                    }
                })
            }), e(document).on("click", ".tree_view_popup .close", function() {
                e(this).closest(".tree_view_popup").remove()
            })), l && e(document).on("click", "." + v + "[rel = " + g + "] span.add_action", function() {
                var t = e(this);
                e(this).closest("div").find("span.add_action, span.edit_action, span.delete_action, span.highlight").hide(), e("form.add_data").length > 0 && e("form.add_data").remove(), e("form.edit_data").length > 0 && e("form.edit_data").remove();
                var i = {
                    action: "addform",
                    tree_id: g
                };
                e.ajax({
                    type: "POST",
                    url: "admin-ajax.php",
                    data: i,
                    success: function(i) {
                        var l = i;
                        e(".form_box").remove(), t.closest(".tree").find(".z-index").removeClass("z-index"), t.parent("div").addClass("z-index").append("<section class='form_box'>" + l + "</section>")
                    }
                }), e(document).on("click", "input.submit", function(t) {
                    var i = e(this);
                    t.preventDefault();
                    var l = i.closest("div").attr("id"),
                        n = new FormData(i.closest("form")[0]),
                        d = "action=add&parent_id=" + l + "&tree_id=" + g;
                    i.closest("li").before("<img src='images/load.gif' class='load' />"), e.ajax({
                        type: "POST",
                        url: "admin-ajax.php?" + d,
                        data: n,
                        enctype: "multipart/form-data",
                        processData: !1,
                        contentType: !1,
                        cache: !1,
                        success: function(t) {
                            e("img.load").remove();
                            var l = jQuery.parseJSON(t);
                            if (!1 === l.msg) alert(l.msg_text);
                            else {
                                e(document).off("click", "input.submit");
                                var n = i.closest("form.add_data").closest("li");
                                i.closest("form.add_data").find(".close").trigger("click"), n.append(l.html), s || n.find("#" + l.msg_text).find(".edit_action").remove(), a || n.find("#" + l.msg_text).find(".delete_action").remove(), j(), c && z()
                            }
                        }
                    })
                }), e(document).on("click", "img.close", function() {
                    e(document).off("click", "input.submit"), e(this).closest(".tree").find(".z-index").removeClass("z-index"), e(this).closest(".form_box").remove()
                })
            }), s && e(document).on("click", "." + v + "[rel = " + g + "] span.edit_action", function() {
                var t = e(this);
                t.closest("div").find("span.add_action, span.edit_action, span.delete_action, span.highlight").hide(), e("form.add_data").length > 0 && e("form.add_data").remove(), e("form.edit_data").length > 0 && e("form.edit_data").remove();
                var i = {
                    action: "editform",
                    edit_ele_id: t.closest("div").attr("id"),
                    tree_id: g
                };
                e.ajax({
                    type: "POST",
                    url: "admin-ajax.php",
                    data: i,
                    success: function(i) {
                        var l = i;
                        e(".form_box").remove(), t.closest(".tree").find(".z-index").removeClass("z-index"), t.closest("div").addClass("z-index").append("<section class='form_box'>" + l + "</section>")
                    }
                }), e(document).on("click", "input.edit", function(t) {
                    var i = e(this);
                    t.preventDefault();
                    var l = "action=edit&id=" + i.closest("div").attr("id"),
                        s = new FormData(i.closest("form")[0]);
                    i.closest("li").before("<img src='images/load.gif' class='load' />"), e.ajax({
                        type: "POST",
                        url: "admin-ajax.php?" + l,
                        data: s,
                        enctype: "multipart/form-data",
                        processData: !1,
                        contentType: !1,
                        cache: !1,
                        success: function(t) {
                            e("img.load").remove();
                            var l = jQuery.parseJSON(t);
                            if (!1 === l.msg) alert(l.msg_text);
                            else {
                                e(document).off("click", "input.edit"), i.closest("form").find("input:checked").length > 0 ? 0 == i.closest("li").hasClass("thide") && i.closest("div").find("b.thide").trigger("click") : i.closest("li").hasClass("thide") && i.closest("div").find("b.thide").trigger("click");
                                var s = i.closest("form.edit_data").closest("div");
                                i.closest("form.edit_data").find(".close").trigger("click"), s.find(".title").text(l.title), l.img && s.find(".img").attr("src", l.img), j()
                            }
                        }
                    })
                }), e(document).on("click", "img.close", function() {
                    e(document).off("click", "input.edit"), e(this).closest(".tree").find(".z-index").removeClass("z-index"), e(this).closest(".form_box").remove()
                })
            }), a && e(document).on("click", "." + v + "[rel = " + g + "] span.delete_action", function() {
                var t = e(this);
                if (1 == t.closest("div").attr("id")) alert("You cant delete root person");
                else {
                    var i = t.closest("li").closest("ul").closest("li"),
                        l = 1;
                    if (n) {
                        var s = 0 === t.closest("li").children("ul").length ? "Do you want to deleat this?" : "Do you want to deleat this with\nall child elements?";
                        l = confirm(s)
                    }
                    if (l) {
                        t.closest("li").addClass("ajax_delete_all");
                        var a = Array();
                        a.push(t.closest("div").attr("id")), e(".ajax_delete_all li").each(function() {
                            a.push(e(this).children("div").attr("id"))
                        }), t.closest("li").removeClass("ajax_delete_all");
                        var d = {
                            action: "delete",
                            id: a,
                            tree_id: g
                        };
                        t.closest("li").before("<img src='images/load.gif' class='load' />"), e.ajax({
                            type: "POST",
                            url: "admin-ajax.php",
                            data: d,
                            success: function(l) {
                                l && (e("img.load").remove(), t.closest("li").fadeOut().remove(), j(), 0 == i.children("ul").children("li").length && i.children("ul").remove())
                            }
                        })
                    }
                }
            }), c && z()
        })
    }
}(jQuery);